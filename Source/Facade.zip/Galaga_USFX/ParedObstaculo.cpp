// Fill out your copyright notice in the Description page of Project Settings.


#include "ParedObstaculo.h"

AParedObstaculo::AParedObstaculo()
{
    // Carga el StaticMesh
    static ConstructorHelpers::FObjectFinder<UStaticMesh> ShipMesh(TEXT("StaticMesh'/Game/StarterContent/Shapes/Shape_Trim.Shape_Trim'"));

    // Crea el componente de malla est�tica
    UStaticMeshComponent* Obstaculo = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Obstaculo"));
    RootComponent = Obstaculo;
    Obstaculo->SetWorldScale3D(FVector(1.0f, 1.0f, 1.0f));

    ciclos=0;
}
void AParedObstaculo::BeginPlay()
{
}
void AParedObstaculo::Tick(float DeltaTime)
{
    if (ciclos < 4)
    {

        Mover(DeltaTime);
    }
    else Destroy();
}

void AParedObstaculo::Mover(float DeltaTime)
{
    FVector PosicionActual = GetActorLocation();

    // Definir los l�mite DERECHO E IZQUIERDO de movimiento
    float LimiteDerecho = 1000.0f;
    float LimiteIzquierdo = -1000.0f;

    // Definir la velocidad de movimiento horizontal
    float VelocidadHorizontal = 300.0f;

    // Calcular el desplazamiento horizontal para este fotograma
    float DesplazamientoHorizontal = VelocidadHorizontal * DeltaTime;

    // Verificar si la nave est� movi�ndose hacia derecha o izquierda

    if (direccion== 1) // Movimiento hacia derecha
    {

        // Mover la nave hacia derecha
        FVector NuevaPosicion = PosicionActual + FVector(0.0f, DesplazamientoHorizontal - 1.0f, 0.0f);
        if (NuevaPosicion.Y <= LimiteDerecho)
        {
            SetActorLocation(NuevaPosicion);
        }
        else
        {
            // Si alcanza el l�mite superior, cambiar la direcci�n de movimiento a hacia izquierda
            direccion = -1;
        }
    }
    else // Movimiento hacia izquierda
    {
        // Mover la nave hacia izquierda
        FVector NuevaPosicion = PosicionActual - FVector(0.0f, DesplazamientoHorizontal - 1.0f, 0.0f);
        if (NuevaPosicion.Y >= LimiteIzquierdo)
        {
            SetActorLocation(NuevaPosicion);
        }
        else
        {
            // Si alcanza el l�mite de la izquierda, cambiar la direcci�n de movimiento a hacia la derecha
            direccion = 1;
            SetActorLocation(FVector(NuevaPosicion.X, NuevaPosicion.Y - 100.0f, NuevaPosicion.Z));
        }
    }
}
