// Fill out your copyright notice in the Description page of Project Settings.


#include "Subscriptor.h"

// Add default functionality here for any ISubscriptor functions that are not pure virtual.
