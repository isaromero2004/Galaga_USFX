// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "NaveEnemigaReabastecimiento.h"
#include "NaveEnemigaReabastecimientoG2.generated.h"

/**
 * 
 */
UCLASS()
class GALAGA_USFX_API ANaveEnemigaReabastecimientoG2 : public ANaveEnemigaReabastecimiento
{
	GENERATED_BODY()


private:
	int vidas;

public:
	ANaveEnemigaReabastecimientoG2();
	FORCEINLINE float GetVidas() const { return vidas; }
	FORCEINLINE void SetVidas(float _vidas) { vidas = _vidas; }

protected:
	virtual void Mover()override;
	virtual void Destruirse()override;
	virtual void Escapar()override;
	virtual void Atacar()override;


};
